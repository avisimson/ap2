package com.example.avi.androidapp;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.util.Log;
import android.widget.Toast;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
public class ImageServiceService extends Service {
    private OutputStream outputStream;
    private Socket socket;
    private BroadcastReceiver receiver;
    private int portOfConnection = 8000;
    private String ipOfConnection = "10.0.2.2";
    //constructor.
    public ImageServiceService(){}
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    //onCreate - when service is being created and started for first time.
    //onCreate opens new thread and tries to connect to a server service.
    @Override
    public void onCreate() {
        super.onCreate();
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                //tcp connection.
                try {
                    InetAddress serverAddr = InetAddress.getByName(ipOfConnection);
                    socket = new Socket(serverAddr, portOfConnection);
                    try {
                        outputStream = socket.getOutputStream();
                    } catch (Exception e) {
                        Log.e("TCP", "S: Error:", e);
                    }
                } catch (Exception e) {
                    Log.e("TCP", "S: Error:", e);
                }
            }
        });
        thread.start();
    }
    /*
    function is activated every time service is being started.
     */
    @Override
    public int onStartCommand(Intent intent, int flag, int startId) {
        //message showing
        Toast.makeText(this, "Service starting.....", Toast.LENGTH_SHORT).show();
        //start wifi connection.
        startLookForWifi();
        return START_STICKY;
    }
    //function gets wifi connection to app.
    public void startLookForWifi() {
        final IntentFilter theFilter = new IntentFilter();
        theFilter.addAction("android.net.wifi.supplicant.CONNECTION_CHANGE");
        theFilter.addAction("android.net.wifi.STATE_CHANGE");
        this.receiver = new BroadcastReceiver() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onReceive(Context context, Intent intent) {
                WifiManager wifiManager = (WifiManager) context
                        .getSystemService(Context.WIFI_SERVICE);
                NetworkInfo networkInfo = intent.getParcelableExtra(wifiManager.EXTRA_NETWORK_INFO);
                final NotificationManager notificationManager = (NotificationManager)
                        context.getSystemService(Context.NOTIFICATION_SERVICE);
                NotificationChannel channel = new NotificationChannel("default",
                        "progress", NotificationManager.IMPORTANCE_DEFAULT);
                notificationManager.createNotificationChannel(channel);
                final NotificationCompat.Builder builder =
                        new NotificationCompat.Builder(context, "default");
                builder.setContentTitle("Picture Transfer")
                        .setContentText("Transfer in progress")
                        .setSmallIcon(R.drawable.ic_launcher_background);
                if (networkInfo != null) {
                    if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                        //gets all different connected networks.
                        if (networkInfo.getState() == NetworkInfo.State.CONNECTED) {
                            startTransfer(notificationManager, builder);    //transfer the pics.
                        }
                    }
                }
            }
        };
        // Registers the receiver so that your service will listen for
        // broadcasts
        this.registerReceiver(this.receiver, theFilter);
    }
    /*
    onDestroy is activated when service is being stopped and closes channel of connection.
     */
    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "Service ending...", Toast.LENGTH_SHORT).show();
        //try close the connection to imageService
        try {
            this.socket.close();
        } catch (IOException e) { //case of error in close connection.
            Log.e("TCP", "S: Error:", e);
        }
    }
    /*
    the function is activated when service starts, and in charge on moving the pics to imageservice.
    @param notificationManager is in charge of the notifications to user.
    @param builder builds the progress bar.
     */
    public void
    startTransfer(final NotificationManager notificationManager,
                  final NotificationCompat.Builder builder) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                //get to DCIM inside the android.
                File dcim =
                        new File(Environment
                                .getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                                "Camera");
                if (dcim == null) {
                    //case of DCIM folder empty from pics.
                    return;
                }
                File[] pics = dcim.listFiles(); //list of all pictures in DCIM folder.
                int picsMoved = 0, progress = 0;
                String toSend;
                byte[] imageByte;
                if (pics != null) {
                    for (File pic : pics) {
                        try {
                            FileInputStream fis = new FileInputStream(pic);
                            Bitmap bitmap = BitmapFactory.decodeStream(fis);
                            imageByte = getBytesFromBitmap(bitmap);
                            try {
                                //sends the size of bytes.
                                toSend = imageByte.length + "";
                                outputStream.write(toSend.getBytes(),
                                        0, toSend.getBytes().length);
                                outputStream.flush();
                                Thread.sleep(1000);
                                //sends the file name.
                                toSend = pic.getName();
                                outputStream.write(toSend.getBytes(),
                                        0, toSend.getBytes().length);
                                outputStream.flush();
                                Thread.sleep(1000);
                                //sends the array bytes.
                                outputStream.write(imageByte, 0, imageByte.length);
                                outputStream.flush();
                                Thread.sleep(2000);

                            } catch (Exception e) { //case of sending fail.
                                Log.e("TCP", "S: Error:", e);
                            }
                        } catch (Exception e) { //case of moving pic to bytes fail.
                            Log.e("TCP", "S: Error:", e);
                        }
                        picsMoved++;
                        //PROGRESS BAR TO USER.
                        progress = (picsMoved/pics.length) * 100;
                        builder.setProgress(100, progress, false);
                        builder.setContentText(progress + "%");
                        notificationManager.notify(1, builder.build());

                    }
                    try {
                        //send to service that sending completed and notify the user.
                        toSend = "complete\n";
                        outputStream.write(toSend.getBytes(), 0, toSend.getBytes().length);
                        outputStream.flush();
                        builder.setContentTitle("Transfer Completed");
                        builder.setContentText("photos moved to your CP");
                        notificationManager.notify(1, builder.build());

                    } catch (Exception e) {
                        //case of comlete sending failed.
                        builder.setContentTitle("Error");
                        builder.setContentText("photos didn't move to your CP");
                        notificationManager.notify(1, builder.build());
                        Log.e("TCP", "S: Error:", e);
                    }
                }
            }
        });
        thread.start();
    }
    /**
     * gets bytes from the bitmap
     * @param bitmap is the decoded picture.
     * @return the bytes of picture.
     */
    public byte[] getBytesFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 70, stream);
        return stream.toByteArray();
    }
}